# Română RU – Android (Kotlin + Compose)

Build (Debug):
./gradlew assembleDebug

APK path:
app/build/outputs/apk/debug/app-debug.apk
